var valorEmDolarTexto = prompt("Qual o valor em Dólar você quer converter?")

var valorEmDolarNum = parseFloat(valorEmDolarTexto)

alert(valorEmDolarNum)

var valorEmReal = valorEmDolarNum * 5.50
var valorEmRealDec = valorEmReal.toFixed(2)

alert(valorEmRealDec)